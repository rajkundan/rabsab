package model;

import java.util.List;

import javax.xml.bind.annotation.*;

@XmlRootElement
@XmlSeeAlso(Books.class)
public class BooksArray {

	List<Books> booksList;
	
	@XmlElement
	public List<Books> getBooksList() {
		return booksList;
	}

	public void setBooksList(List<Books> booksList) {
		this.booksList = booksList;
	}

	
	
	

	
	
	
}
