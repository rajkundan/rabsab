package model;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class User {

	int id,role;
	String name,mailId,password;
	
	//Constants to represents the role values
	public static final int user=1;
	public static final int admin=2;
	

	public User() {
		super();
		
	}

	public User(String name, String mailId, 
			String password,int role) {
		this.name = name;
		this.mailId = mailId;
		this.password = password;
		this.role=role;
	}
	@XmlElement
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	@XmlElement
	public int getRole() {
		return role;
	}

	public void setRole(int role) {
		this.role = role;
	}
	@XmlElement
	public String getName() {
		return name;
	}

	
	public void setName(String name) {
		this.name = name;
	}
	@XmlElement
	public String getMailId() {
		return mailId;
	}
	
	public void setMailId(String mailId) {
		this.mailId = mailId;
	}
	@XmlElement
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	
	
	
}
