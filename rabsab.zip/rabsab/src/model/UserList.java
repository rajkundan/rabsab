package model;

import java.util.List;

import javax.xml.bind.annotation.*;

@XmlRootElement
@XmlSeeAlso(User.class)
public class UserList {

	List<User> list;

	@XmlElement
	public List<User> getList() {
		return list;
	}

	public void setList(List<User> list) {
		this.list = list;
	}
	
	
}
