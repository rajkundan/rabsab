package model;

import java.util.List;

import javax.xml.bind.annotation.*;

@XmlRootElement
@XmlSeeAlso(Book.class)
public class Books {

	String category;
	List<Book> list;

	
	@XmlElement
	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	@XmlElement
	public List<Book> getList() {
		return list;
	}

	public void setList(List<Book> list) {
		this.list = list;
	}
	
	
}
