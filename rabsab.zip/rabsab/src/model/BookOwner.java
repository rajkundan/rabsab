package model;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class BookOwner {
 private String name,mailid,mobile,city;

 @XmlElement
public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}
@XmlElement
public String getMailid() {
	return mailid;
}

public void setMailid(String mailid) {
	this.mailid = mailid;
}
@XmlElement
public String getMobile() {
	return mobile;
}

public void setMobile(String mobile) {
	this.mobile = mobile;
}
@XmlElement
public String getCity() {
	return city;
}

public void setCity(String city) {
	this.city = city;
}
 
 
}
