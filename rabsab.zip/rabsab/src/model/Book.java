package model;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Book {
private int bookId,userId,rent,status;
private String title,category,imageUrl;

public static final int available=1;
public static final int rented=2;

@XmlElement
public int getBookId() {
	return bookId;
}
public void setBookId(int bookId) {
	this.bookId = bookId;
}
@XmlElement
public int getUserId() {
	return userId;
}
public void setUserId(int userId) {
	this.userId = userId;
}
@XmlElement
public int getRent() {
	return rent;
}
public void setRent(int rent) {
	this.rent = rent;
}
@XmlElement
public int getStatus() {
	return status;
}
public void setStatus(int status) {
	this.status = status;
}
@XmlElement
public String getTitle() {
	return title;
}
public void setTitle(String title) {
	this.title = title;
}
@XmlElement
public String getCategory() {
	return category;
}
public void setCategory(String category) {
	this.category = category;
}
@XmlElement
public String getImageUrl() {
	return imageUrl;
}
public void setImageUrl(String imageUrl) {
	this.imageUrl = imageUrl;
}


}
