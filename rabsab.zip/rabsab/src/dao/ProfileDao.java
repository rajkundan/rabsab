package dao;

import java.sql.*;

import model.Profile;
import model.User;

public class ProfileDao {

	//to Save a Profile
	public void save(Profile profile) throws Exception
	{
		//connection is created.
		Connection con=
		ConnectionProvider.getConnection();
		//statement is created.
		PreparedStatement stmt=
		con.prepareStatement(
"insert into UserProfile values(?,?,?,?,?,?,?,?)");
		//setting parameters values
		stmt.setInt(1,profile.getProfileId());
		stmt.setString(2, profile.getMobile());
		stmt.setString(3, profile.getQuestion());
		stmt.setString(4, profile.getAnswer());
		stmt.setString(5, profile.getStreet());
		stmt.setString(6, profile.getCity());
		stmt.setString(7, profile.getState());
		stmt.setString(8, profile.getPin());
		//Query is executed
		stmt.executeUpdate();
		//connection is closed
		con.close();
	}
	
	//to update a Profile
		public void update(Profile profile) throws Exception
		{
			//connection is created.
			Connection con=
			ConnectionProvider.getConnection();
			//statement is created.
			PreparedStatement stmt=
			con.prepareStatement(
	"update UserProfile set mobileNo=?,secretQuestion=?,secretAnswer=?,street=?,city=?,state=?,pin=? where profileId=?");
			//setting parameters values
			stmt.setString(1, profile.getMobile());
			stmt.setString(2, profile.getQuestion());
			stmt.setString(3, profile.getAnswer());
			stmt.setString(4, profile.getStreet());
			stmt.setString(5, profile.getCity());
			stmt.setString(6, profile.getState());
			stmt.setString(7, profile.getPin());
			stmt.setInt(8,profile.getProfileId());
			//Query is executed
			stmt.executeUpdate();
			//connection is closed
			con.close();
		}
		
	
	
	//utility method to map a UserMaster record to a User object.
	public Profile mapUser(ResultSet rset) throws Exception
	{
		Profile profile=new Profile();
		profile.setProfileId(rset.getInt(1));
		profile.setMobile(rset.getString(2));
		profile.setQuestion(rset.getString(3));
		profile.setAnswer(rset.getString(4));
		profile.setStreet(rset.getString(5));
		profile.setCity(rset.getString(6));
		profile.setState(rset.getString(7));
		profile.setPin(rset.getString(8));
		System.out.println("object mapped.");
		return profile;
	}
	
	//to load a profile using userId 
	public Profile loadProfile(int userId) throws Exception
	{
		Profile profile=null;
		Connection con=
				ConnectionProvider.getConnection();
		PreparedStatement stmt=
		con.prepareStatement("select * from UserProfile where profileId=?");
		stmt.setInt(1, userId);
		ResultSet rset=stmt.executeQuery();
		if(rset.next())
			profile=mapUser(rset);
		
		con.close();
		return profile;
		
	}
	
	//to delete a profile
	public void delete(int profileId) throws Exception
	{
		//connection is created.
		Connection con=
		ConnectionProvider.getConnection();
		//statement is created.
		PreparedStatement stmt=
		con.prepareStatement("delete from UserProfile where profileId=?");
		//setting parameters values
		stmt.setInt(1,profileId);
		//Query is executed
		stmt.executeUpdate();
		//connection is closed
		con.close();
		System.out.println("profile deleted.");
	}
}
