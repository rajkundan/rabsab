package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import model.Book;
import model.User;

public class BookDao {

	
	public void save(Book book) throws Exception
	{
		Connection con=ConnectionProvider.getConnection();
		PreparedStatement stmt=con.prepareStatement(
		"insert into BookMaster (userId,title,category,imgUrl,rent,status) "
		+ "values(?,?,?,?,?,?)");
		stmt.setInt(1, book.getUserId());
		stmt.setString(2, book.getTitle());
		stmt.setString(3, book.getCategory());
		stmt.setString(4, book.getImageUrl());
		stmt.setInt(5, book.getRent());
		stmt.setInt(6, book.getStatus());
		stmt.executeUpdate();
		con.close();
		System.out.println("book details saved.");
	}
	
	public void update(Book book) throws Exception
	{
		Connection con=ConnectionProvider.getConnection();
		PreparedStatement stmt=con.prepareStatement(
		"update BookMaster set title=?,category=?,rent=?,status=? "
		+ "where bookId=?");
		stmt.setString(1, book.getTitle());
		stmt.setString(2, book.getCategory());
		stmt.setInt(3, book.getRent());
		stmt.setInt(4, book.getStatus());
		stmt.setInt(5, book.getBookId());
		stmt.executeUpdate();
		con.close();
		System.out.println("book details updated.");
	}
	public void updateImageUrl(int bookId, String imgUrl) throws Exception
	{
		Connection con=ConnectionProvider.getConnection();
		PreparedStatement stmt=con.prepareStatement(
		"update BookMaster set imgUrl=? where bookId=?");
		stmt.setString(1, imgUrl);
		stmt.setInt(2, bookId);
		stmt.executeUpdate();
		con.close();
		System.out.println("image url of bookId "+bookId+" updated to "+imgUrl);
	}
	
	public int getUserId(int bookId) throws Exception
	{
		int userId=0;
		Connection con=ConnectionProvider.getConnection();
		PreparedStatement stmt=con.prepareStatement(
		"select userId from BookMaster where bookId=?");
		stmt.setInt(1, bookId);
		ResultSet rset=stmt.executeQuery();
		if(rset.next())
			userId=rset.getInt(1);
		con.close();
		return userId;
	}
	
	//to delete a book
	public void delete(int bookId) throws Exception
	{
		Connection con=ConnectionProvider.getConnection();
		PreparedStatement stmt=con.prepareStatement(
		"delete from BookMaster where bookId=?");
		stmt.setInt(1, bookId);
		stmt.executeUpdate();
		con.close();
		
	}
	
	//utility method to map a BookMaster record to a Book object.
		public Book mapBook(ResultSet rset) throws Exception
		{
			Book book=new Book();
			book.setBookId(rset.getInt(1));
			book.setUserId(rset.getInt(2));
			book.setTitle(rset.getString(3));
			book.setCategory(rset.getString(4));
			book.setImageUrl(rset.getString(5));
			book.setRent(rset.getInt(6));
			book.setStatus(rset.getInt(7));
			System.out.println("object mapped.");
			return book;
		}
		
		//to load all the books
				public List<Book> allBooks() throws Exception
				{
					List<Book> list=new ArrayList<Book>();
					Connection con=
							ConnectionProvider.getConnection();
					Statement stmt=con.createStatement();
					ResultSet rset=stmt.executeQuery("select * from BookMaster");
					while(rset.next())
						list.add(mapBook(rset));
					
					con.close();
					return list;
					
				}
		
				//to load all the books of a user
				public List<Book> allBooksOfUser(int userId) throws Exception
				{
					List<Book> list=new ArrayList<Book>();
					Connection con=
							ConnectionProvider.getConnection();
					PreparedStatement stmt=con.prepareStatement(
					"select * from BookMaster where userId=?");
					stmt.setInt(1, userId);
					ResultSet rset=stmt.executeQuery();
					while(rset.next())
						list.add(mapBook(rset));
					
					con.close();
					return list;
					
				}
				

				//to load all the books of a city
				public List<Book> booksOfCity(String city) throws Exception
				{
					List<Book> list=new ArrayList<Book>();
					Connection con=
							ConnectionProvider.getConnection();
					PreparedStatement stmt=con.prepareStatement(
					"select * from BookMaster bm, UserProfile up where bm.userId=up.profileId and up.city=?");
					stmt.setString(1, city);
					ResultSet rset=stmt.executeQuery();
					while(rset.next())
						list.add(mapBook(rset));
					
					con.close();
					return list;
					
				}
				
				//to load all the available/rented books
				public List<Book> bookByStatus(int status) throws Exception
				{
					List<Book> list=new ArrayList<Book>();
					Connection con=
							ConnectionProvider.getConnection();
					PreparedStatement stmt=con.prepareStatement(
					"select * from BookMaster where status=?");
					stmt.setInt(1, status);
					ResultSet rset=stmt.executeQuery();
					while(rset.next())
						list.add(mapBook(rset));
					
					con.close();
					return list;
					
				}
				
				
				//to load all the books of a category
				public List<Book> allBooksOfCategory(String cat) throws Exception
				{
					List<Book> list=new ArrayList<Book>();
					Connection con=
							ConnectionProvider.getConnection();
					PreparedStatement stmt=con.prepareStatement(
					"select * from BookMaster where category=?");
					stmt.setString(1, cat);
					ResultSet rset=stmt.executeQuery();
					while(rset.next())
						list.add(mapBook(rset));
					
					con.close();
					return list;
					
				}
				
				//to load all the unique categories
				public List<String> getAllCategories() throws Exception
				{
					List<String> list=new ArrayList<String>();
					Connection con=
							ConnectionProvider.getConnection();
					PreparedStatement stmt=con.prepareStatement(
					"select distinct category from BookMaster");
					
					ResultSet rset=stmt.executeQuery();
					while(rset.next())
						list.add(rset.getString(1));
					
					con.close();
					return list;
					
				}
				
}
