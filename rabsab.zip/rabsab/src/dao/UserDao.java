package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import model.BookOwner;
import model.User;

public class UserDao {

	//to Save a user
	public void save(User user) throws Exception
	{
		//connection is created.
		Connection con=
		ConnectionProvider.getConnection();
		//statement is created.
		PreparedStatement stmt=
		con.prepareStatement("insert into UserMaster (name,mailId,password,role) values(?,?,?,?)");
		//setting parameters values
		stmt.setString(1, user.getName());
		stmt.setString(2, user.getMailId());
		stmt.setString(3, user.getPassword());
		stmt.setInt(4, user.getRole());
		//Query is executed
		stmt.executeUpdate();
		//connection is closed
		con.close();
		System.out.println("user saved.");
	}
	
	//to Save a user
		public void update(User user) throws Exception
		{
			//connection is created.
			Connection con=
			ConnectionProvider.getConnection();
			//statement is created.
			PreparedStatement stmt=
			con.prepareStatement("update UserMaster set name=?,mailId=?,password=? where id=?");
			//setting parameters values
			stmt.setString(1, user.getName());
			stmt.setString(2, user.getMailId());
			stmt.setString(3, user.getPassword());
			stmt.setInt(4, user.getId());
			//Query is executed
			stmt.executeUpdate();
			//connection is closed
			con.close();
			System.out.println("user updated.");
		}
		
		
		//to delete a user
				public void delete(int userId) throws Exception
				{
					//connection is created.
					Connection con=
					ConnectionProvider.getConnection();
					//statement is created.
					PreparedStatement stmt=
					con.prepareStatement("delete from UserMaster where id=?");
					//setting parameters values
					stmt.setInt(1,userId);
					//Query is executed
					stmt.executeUpdate();
					//connection is closed
					con.close();
					System.out.println("user deleted.");
				}
				
		
		//to change password
				public void changePassword(int id,String password ) throws Exception
				{
					//connection is created.
					Connection con=
					ConnectionProvider.getConnection();
					//statement is created.
					PreparedStatement stmt=
					con.prepareStatement("update UserMaster set password=? where id=?");
					//setting parameters values
					stmt.setString(1, password);
					stmt.setInt(2, id);
					//Query is executed
					stmt.executeUpdate();
					//connection is closed
					con.close();
					System.out.println("password changed.");
				}
			
		
	//utility method to map a UserMaster record to a User object.
	public User mapUser(ResultSet rset) throws Exception
	{
		User user=new User();
		user.setId(rset.getInt(1));
		user.setName(rset.getString(2));
		user.setMailId(rset.getString(3));
		user.setPassword(rset.getString(4));
		user.setRole(rset.getInt(5));
		System.out.println("object mapped.");
		return user;
	}
	
	
	//to load all users
		public List<User> allUsers() throws Exception
		{
			List<User> list=new ArrayList<User>();
			Connection con=
					ConnectionProvider.getConnection();
			Statement stmt=con.createStatement();
			ResultSet rset=stmt.executeQuery("select * from UserMaster");
			while(rset.next())
				list.add(mapUser(rset));
			
			con.close();
			return list;
			
		}
	
	//to search a user using mailId and password
	public User findUser(String m,String p) throws Exception
	{
		User user=null;
		Connection con=
				ConnectionProvider.getConnection();
		PreparedStatement stmt=
				con.prepareStatement("select * from UserMaster where mailId=? and password=?");
		stmt.setString(1, m);
		stmt.setString(2, p);
		ResultSet rset=stmt.executeQuery();
		if(rset.next())
			user=mapUser(rset);
		
		con.close();
		return user;
		
	}
	
	//to return name,mailId,mobile and city of a user 
		public BookOwner getDetails(int userId) throws Exception
		{
			BookOwner owner=null;
			Connection con=
					ConnectionProvider.getConnection();
			PreparedStatement stmt=
					con.prepareStatement("Select a.name, a.mailid, b.mobileNo, b.city from UserMaster a, UserProfile b where a.id=b.profileId and a.id=?");
			stmt.setInt(1, userId);
			ResultSet rset=stmt.executeQuery();
			if(rset.next())
			{   owner=new BookOwner();
				owner.setName(rset.getString(1));
				owner.setMailid(rset.getString(2));
				owner.setMobile(rset.getString(3));
				owner.setCity(rset.getString(4));
			}
			
			con.close();
			return owner;
			
		}
	
	
	//to search userId using mailId
		public int getUserId(String m) throws Exception
		{
			int id=0;
			Connection con=
					ConnectionProvider.getConnection();
			PreparedStatement stmt=
					con.prepareStatement("select * from UserMaster where mailId=?");
			stmt.setString(1, m);
			System.out.println("fetching id using from db  "+m);
			ResultSet rset=stmt.executeQuery();
			if(rset.next())
			{
				id=rset.getInt(1);
				System.out.println("mailId found, returning its id "+id);
			}
			con.close();
			return id;
			
		}
	
	
}
