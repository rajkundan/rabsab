package dao;

import java.io.*;
import java.sql.*;
import java.util.*;

public class ConnectionProvider {

	private static Properties prop;
	
	static
	{
		prop=new Properties();
		try{
		InputStream in=
ConnectionProvider.class.getResourceAsStream(
		"/db.properties");
		prop.load(in);
		}catch(Exception e)
		{
			System.out.println(e);
		}
	}
	public static Connection getConnection() 
			throws Exception
	{
		Connection con=null;
		Class.forName(
			prop.getProperty("driverClass"));
		con=DriverManager.getConnection(
				prop.getProperty("url"),
				prop.getProperty("user"),
				prop.getProperty("password"));
		return con;
	}
}
