package resources;

import java.io.InputStream;
import java.util.*;

import javax.ws.rs.*;
import javax.ws.rs.core.*;

import com.sun.jersey.core.header.FormDataContentDisposition;
import com.sun.jersey.multipart.FormDataParam;

import dao.BookDao;
import dao.ProfileDao;
import dao.UserDao;
import model.*;
import util.FileManager;


@Path("/books")
public class BookService {

	@POST
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	@Produces(MediaType.TEXT_PLAIN)
	public String save(
			@FormDataParam("userId") int userId,
			@FormDataParam("book_img") InputStream fis,
			@FormDataParam("book_img") FormDataContentDisposition fcd,
			@FormDataParam("title") String title,
			@FormDataParam("category") String category,
			@FormDataParam("rent") int rent)
	{
		try{
			String fname=fcd.getFileName();
			String link=null;
			if(fname !=null)
			{
			System.out.println("Saving file...");
			link=FileManager.Save(userId, fis, fname);
			System.out.println("Saved at "+link);
			}
			System.out.println("Saving book details to db...");
			//Creating a Book object
			Book book=new Book();
			book.setUserId(userId);
			book.setTitle(title);
			book.setCategory(category);
			book.setRent(rent);
			book.setImageUrl(link);
			book.setStatus(Book.available);
			BookDao dao=new BookDao();
			dao.save(book);
			return "SUCCESS";
		}catch(Exception ex)
		{
			System.out.println(ex);
			return "FAILURE";
		}
		
	}

	@POST
	@Path("/changeImage")
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	@Produces(MediaType.TEXT_PLAIN)
	public String changeImage(
			@FormDataParam("bookId") int bookId,
			@FormDataParam("userId") int userId,
			@FormDataParam("imgUrl") String imgUrl,
			@FormDataParam("book_img") InputStream fis,
			@FormDataParam("book_img") FormDataContentDisposition fcd)
	{
		try{
			String fname=fcd.getFileName();
			String link=imgUrl;
			if(fname !=null)
			{
			System.out.println("deleting old file...");
			FileManager.delete(imgUrl);
			System.out.println("Saving new File...");
			link=FileManager.Save(userId, fis, fname);
			System.out.println("Saved at "+link);
			}
			BookDao dao=new BookDao();
			dao.updateImageUrl(bookId, link);
			return "SUCCESS";
		}catch(Exception ex)
		{
			System.out.println(ex);
			return "FAILURE";
		}
		
	}

	
	
	
	
	//to return a list of all the books
		@GET
		@Produces(MediaType.APPLICATION_JSON)
		public BooksArray getAllBooks()
		{
			BooksArray ba=new BooksArray();
			try{
				List<Books> bl=new ArrayList<Books>();
				System.out.println("loading categories...");
				BookDao dao=new BookDao();
				List<String> catList=dao.getAllCategories();
				Iterator<String> itr=catList.iterator();
				while(itr.hasNext())
				{
					String cat=itr.next();
					System.out.println("loading books of "+cat);
					List<Book> list=dao.allBooksOfCategory(cat);
					//creating a Books object
					Books bk=new Books();
					bk.setCategory(cat);
					bk.setList(list);
					//adding the Books object to list of Books object
					bl.add(bk);
					
				}
				
				ba.setBooksList(bl);
			}catch(Exception ex)
			{
				System.out.println(ex);
				
			}
			return ba;
		}
		
		
		//to return a list of all the books of a city
		@Path("/byCity/{city}")
		@GET
		@Produces(MediaType.APPLICATION_JSON)
		public BookList BooksOfCity(@PathParam("city") String city)
		{
			BookList bl=new BookList();
			try{
				
				System.out.println("loading books of the city: "+city);
				BookDao dao=new BookDao();
				List<Book> list=dao.booksOfCity(city);
				bl.setList(list);
			}catch(Exception ex)
			{
				System.out.println(ex);
				
			}
			return bl;

		}
		
		//to return a list of all books which are available for rent
				@Path("/available")
				@GET
				@Produces(MediaType.APPLICATION_JSON)
				public BookList availableBooks()
				{
					BookList bl=new BookList();
					try{
						
						System.out.println("loading available books");
						BookDao dao=new BookDao();
						List<Book> list=dao.bookByStatus(Book.available);
						bl.setList(list);
					}catch(Exception ex)
					{
						System.out.println(ex);
						
					}
					return bl;

				}
		
				//to return a list of all books which are rented
				@Path("/rented")
				@GET
				@Produces(MediaType.APPLICATION_JSON)
				public BookList rentedBooks()
				{
					BookList bl=new BookList();
					try{
						
						System.out.println("loading rented books");
						BookDao dao=new BookDao();
						List<Book> list=dao.bookByStatus(Book.rented);
						bl.setList(list);
					}catch(Exception ex)
					{
						System.out.println(ex);
						
					}
					return bl;

				}
	
				
				
				
		//to return a list of all the books of a user
				@Path("/{userId}")
				@GET
				@Produces(MediaType.APPLICATION_JSON)
				public BookList loadUserBooks(@PathParam("userId") int userId)
				{
					BookList bl=new BookList();
					try{
						
						System.out.println("loading books...");
						BookDao dao=new BookDao();
						List<Book> list=dao.allBooksOfUser(userId);
						bl.setList(list);
					}catch(Exception ex)
					{
						System.out.println(ex);
						
					}
					return bl;
				}
				
		
				//to return the owner details of a book
				@Path("/owner/{bookId}")
				@GET
				@Produces(MediaType.APPLICATION_JSON)
				public BookOwner getOwner(@PathParam("bookId") int bookId)
				{
					BookOwner owner=null;
					try{
						
						System.out.println("loading userId of the book...");
						BookDao dao=new BookDao();
						int userId=dao.getUserId(bookId);
						System.out.println("loading user details of: "+userId);
						UserDao udao=new UserDao();
						owner=udao.getDetails(userId);
						System.out.println("Sending "+owner);
					}catch(Exception ex)
					{
						System.out.println(ex);
						
					}
					return owner;
				}
				
				@DELETE
				@Path("/{bookId}")
				@Produces(MediaType.TEXT_PLAIN)
				public String removeUser(@PathParam("bookId")int bookId,
						@QueryParam("imgUrl") String imgUrl)
				{
					try{
						System.out.println("deleting book image...");
						FileManager.delete(imgUrl);
						System.out.println("deleting book details...");
						BookDao dao=new BookDao();
						dao.delete(bookId);
						return "SUCCESS";
					}catch(Exception ex)
					{
						ex.printStackTrace();
						return "FAILURE";
					}
					
				}
		
			//to update a book	
				@PUT
				//@Path("/update")
				@Consumes(MediaType.APPLICATION_JSON)
				@Produces(MediaType.TEXT_PLAIN)
				public String update(Book book)
				{
					try{
						System.out.println("updating book");
						BookDao dao=new BookDao();
						dao.update(book);
						return "SUCCESS";
					}catch(Exception ex)
					{
						ex.printStackTrace();
						return "FAILURE";
					}
					
				}
}



