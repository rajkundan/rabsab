package resources;

import java.util.List;

import javax.ws.rs.*;
import javax.ws.rs.core.*;

import dao.ProfileDao;
import dao.UserDao;
import model.Profile;
import model.User;
import model.UserList;

@Path("/users")
public class UserService {

	UserDao dao;
	
	public UserService()
	{
		dao=new UserDao();
	}
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.TEXT_PLAIN)
	public String save(User user)
	{
		try{
			
			dao.save(user);
			return "SUCCESS";
		}catch(Exception ex)
		{
			System.out.println(ex);
			return "FAILURE";
		}
		
	}
	@PUT
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.TEXT_PLAIN)
	public String update(User user)
	{
		try{
			
			dao.update(user);
			return "SUCCESS";
		}catch(Exception ex)
		{
			ex.printStackTrace();
			return "FAILURE";
		}
		
	}
	
	
	@PUT
	@Path("/profile")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.TEXT_PLAIN)
	public String changePassword(User user)
	{
		try{
			System.out.println("updating password");
			dao.changePassword(user.getId(),user.getPassword());
			return "SUCCESS";
		}catch(Exception ex)
		{
			ex.printStackTrace();
			return "FAILURE";
		}
		
	}
	
	@DELETE
	@Path("/{userId}")
	@Produces(MediaType.TEXT_PLAIN)
	public String removeUser(@PathParam("userId")int userId)
	{
		try{
			System.out.println("deleting user...");
			dao.delete(userId);
			System.out.println("deleting profile...");
			ProfileDao pdao=new ProfileDao();
			pdao.delete(userId);
			return "SUCCESS";
		}catch(Exception ex)
		{
			ex.printStackTrace();
			return "FAILURE";
		}
		
	}
	
	@POST
	@Path("/createOrUpdateProfile")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.TEXT_PLAIN)
	public String saveOrUpdateProfile(Profile profile)
	{
		try{
			System.out.println("saving or updating profile for user "+profile.getProfileId());
			ProfileDao pdao=new ProfileDao();
			Profile p = pdao.loadProfile(profile.getProfileId());
			if(p==null)
			pdao.save(profile);
			else
			pdao.update(profile);	
			return "SUCCESS";
		}catch(Exception ex)
		{
			ex.printStackTrace();
			return "FAILURE";
		}
		
	}
	
	//to return a list of all users
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public UserList allUsers()
	{
		UserList ul=new UserList();
		try{
			
			System.out.println("loading users...");
			List<User> list=dao.allUsers();
			ul.setList(list);
		}catch(Exception ex)
		{
			System.out.println(ex);
			
		}
		return ul;
	}
	
	
	@GET
	@Path("/user")
	@Produces(MediaType.APPLICATION_JSON)
	public User findUser(@QueryParam("mailId") String email,@QueryParam("password") String pwd)
	{
		User user=null;
		try{
			
			System.out.println("Email: "+email+"\tPassword: "+pwd);
			user=dao.findUser(email, pwd);
		}catch(Exception ex)
		{
			System.out.println(ex);
			
		}
		return user;
	}
	
	@GET
	@Path("/profile")
	@Produces(MediaType.APPLICATION_JSON)
	public Profile loadProfile(@QueryParam("userId") int userId)
	{
		Profile profile=null;
		try{
			
			System.out.println("loading profile of the user "+userId);
			ProfileDao pdao=new ProfileDao();
			profile = pdao.loadProfile(userId);
		}catch(Exception ex)
		{
			System.out.println(ex);
			
		}
		return profile;
	}
	
	
	


@GET
@Path("/profile/{mailId}")
@Produces(MediaType.APPLICATION_JSON)
public Profile loadProfile(@PathParam("mailId") String mailId)
{
	Profile profile=null;
	try{
		
		System.out.println("fetching userId using mailId: "+mailId);
		int id=dao.getUserId(mailId);
		System.out.println("loading profile using the id:"+id);
		ProfileDao pdao=new ProfileDao();
		profile = pdao.loadProfile(id);
	}catch(Exception ex)
	{
		System.out.println(ex);
		
	}
	return profile;
}



}



