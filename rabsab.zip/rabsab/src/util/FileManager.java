package util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Random;

public class FileManager {

	private static final String uploadFolder;
	private static String path;
	
	static
	{
		uploadFolder="images"+File.separator+"uploads";
		System.out.println("obtaining path of "+uploadFolder);
		//obtaining classpath of the application
		String cp=FileManager.class.getResource("/").toString();
		System.out.println("classpath is: "+path);
		//removing prefixed file: from the classpath
		cp=cp.substring(5);
		//removing path from WEB-INF from the cp
		cp=cp.substring(0, cp.indexOf("WEB-INF"));
		System.out.println("classpath is: "+cp);
		//adding upload folder path to the obtained path
		path=cp+uploadFolder;
	}
	
	//method to generate unique file name
	private static String getUniqueFileName(String fileName,int userId)
	{
		Random r=new Random();
		int sfx=r.nextInt(1000);
		String flName=fileName.substring(0,fileName.indexOf('.'));
		String flExt=fileName.substring(fileName.indexOf('.'));
		String fname=flName+"_"+Integer.toString(userId)+"_"
		+Integer.toString(sfx)+flExt;
		return fname;
	}
	public static String Save(int userId,InputStream fis,String fileName) throws Exception
	{
		String ufname=getUniqueFileName(fileName,userId);
		String fpath=path+File.separator+ufname;
		File f=new File(fpath);
		
			FileOutputStream fos=new FileOutputStream(f);
			int b;
			while((b=fis.read())!=-1)
			{
				fos.write(b);
			}
			
			fos.close();
			fis.close();
			System.out.println("successfully uploaded.");
		
		//returning file url
		return uploadFolder+File.separator+ufname;
	}
	public static void delete(String fileUrl) throws Exception
	{
		String fname=fileUrl.substring(fileUrl.lastIndexOf(File.separator)+1);
		String fpath=path+File.separator+fname;
		File f=new File(fpath);
		
		f.delete();	
		System.out.println("successfully deleted.");
		
	}
	
	
}
