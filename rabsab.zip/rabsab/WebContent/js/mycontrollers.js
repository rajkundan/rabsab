var m1=angular.module('myApp',['ngRoute']);

//Routes configuration of the application
m1.config( function($routeProvider) {
    
	$routeProvider             
   	   .when('/register', {
       templateUrl: 'registrationForm.html',
       controller: 'UserController'
         
       })
       .when('/login', {
       templateUrl: 'login.html',
       controller: 'UserController'
        
       })
       .when('/profile', {
       templateUrl: 'profile.html',
       controller: 'UserController'
        })
        .when('/users', {
       templateUrl: 'allUsers.html',
       controller: 'UserController'
        })
       .when('/forgot', {
       templateUrl: 'passwordResetForm.html',
       controller: 'UserController'
        })
        .when('/books', {
       templateUrl: 'books.html',
       controller: 'BookController'
        })
       .when('/post_book', {
       templateUrl: 'post_book.html',
       controller: 'BookController'
        })
        .when('/all_books', {
       templateUrl: 'allBooks.html',
       controller: 'BookController'
        })
       .when('/book_details', {
       templateUrl: 'bookDetails.html',
       controller: 'BookController'
        })
        .when('/books_by_city', {
       templateUrl: 'cityBooks.html',
       controller: 'BookController'
        })
         .when('/books_by_status', {
       templateUrl: 'booksByStatus.html',
       controller: 'BookController'
        })
        .when('/howItWorks', {
       templateUrl: 'howItWorks.html'
           })
       .otherwise({
    	   templateUrl: 'home.html',
    	   controller: 'HomeController'
     });

   
});

//Notification Service
m1.factory('Notifier',function($rootScope){
	
	return{
		
		displayMsg: function(msg,alertClass){
			$rootScope.msg=msg;
			$rootScope.alertClass=alertClass;
			$rootScope.notify=true;
		}
	};
});

//Notification Controller
m1.controller('NotifyController',
		function($rootScope,$scope){
	
	$scope.toggleNotify=function(){
		//alert("clicked.");
	$rootScope.notify=!$rootScope.notify;	
	};
	
});




//controller is defined & registered with the module
m1.controller('UserController',
		function($scope,$location,$rootScope,$http,Notifier){
	
	//formData object is created and default values are provided for id and role.
	$scope.formData={
			'id':1,
			'role':1	
	};
	//profile questions
	$scope.questions=["What is your mother's maiden name?",
	                  "What is your place of birth?",
	                  "Which was your first smart phone?",
	                  "Which brand was your first laptop/computer?",
	                  "What was the name of your first school?",
	                  "Who is your role model?",
	                  "What is your blood group?"
	                 ];
	
	/*//function to obtain selected question.
	$scope.selectedQ=function(){
		
	//$scope.profile.question=questions[index];
	alert("Selected: "+$scope.profile.question);
	};*/
		
	//function to get a user saved.
	$scope.saveUser=function(){
		
		//alert("Saving: "+JSON.stringify($scope.formData));
		$http.post("http://localhost:8080/rabsab/services/users",$scope.formData)
		.then(function(response){
			
			if(response.data=="SUCCESS")
				Notifier.displayMsg("You are successfully registered, proceed to login.","alert-success");
			else
				Notifier.displayMsg("Registration Failed.","alert-danger");
				
		},
			function(error){
			Notifier.displayMsg("Connection to the server is failed, try again later.","alert-danger");
			});
				
		
		$location.path('login');//path is changed so that registration form is replaced.
	};
		
	//function to login a user
	$scope.userLogin=function(email,pwd){
		//alert("login details: "+email+", "+pwd);
		var url="http://localhost:8080/rabsab/services/users/user?mailId="+email+"&password="+pwd;
		$http.get(url).then(function(response){
			var len=Object.keys(response.data).length;//length of data object is obtained
			//alert("response length: "+len);
			if(len>0)
				{
				$rootScope.user=response.data;
				if($rootScope.user.role==1)
				$rootScope.top="topUser.html";
				else
					$rootScope.top="topAdmin.html";	
				
				Notifier.displayMsg("If your profile is not complete, then complete it now.","alert-danger");
				$scope.loadProfile();
				$location.path('profile');
				}
			else
				{
				Notifier.displayMsg("Invalid MailId or Password, try again.","alert-danger");
				}
		},function(error){
			Notifier.displayMsg("Connection to the server is failed, try again later.","alert-danger");
		});
	};
	
	//function to logout user
	$scope.logout=function(){
		$rootScope.user=null;//user object is removed from the root scope.
		$rootScope.profile=null;//profile object is removed from the root scope.
		$location.path('home');//path is changed to home.
		$rootScope.top="toplinks.html"; //signup and sign in links are displayed again.
		Notifier.displayMsg("You have successfully logged out.","alert-success");
		//alert("logged out.");
	};
	
	//function to load the user profile
	$scope.loadProfile=function(){
		var url="http://localhost:8080/rabsab/services/users/profile?userId="+$rootScope.user.id;
		//alert("sending request for "+url);
		$http.get(url).then(function(response){
			var len=Object.keys(response.data).length;//length of data object is obtained
			//alert("response length: "+len);
			if(len>0)
				{
				$rootScope.profile=response.data;
				//alert("Non-Empty user profile.");
				}
			else
				{
				$rootScope.profile={'profileId':$rootScope.user.id,
						'mobile':'',
						'question':'',
						'answer':'',
						'street':'',
						'city':'',
						'state':'',
						'pin':''};
				//alert(JSON.stringify($rootScope.profile));
				}
		},function(error){
			Notifier.displayMsg("Connection to the server is failed, try again later.","alert-danger");
		});
		
	};
	
	
	
	//function to save or update user profile
	$scope.saveOrUpdateProfile=function(){
		
		//var prof=JSON.stringify($rootScope.profile);
		//alert("profile details: "+prof);
		//sending put request to get the user updated
		$http.put("http://localhost:8080/rabsab/services/users",$rootScope.user)
		.then(function(response){
			
			if(response.data=="SUCCESS")
				{
				//user details updated, get the profile saved or updated.
				$http.post("http://localhost:8080/rabsab/services/users/createOrUpdateProfile",$rootScope.profile)
				.then(function(response){
					if(response.data=="SUCCESS")
						{
						Notifier.displayMsg("Profile successfully updated.","alert-success");
						$location.path('home');
						}
					else
						{
						Notifier.displayMsg("Updation failed, try again.","alert-danger");
						}
				},function(error){
					Notifier.displayMsg("Connection to the server is failed, try again later.","alert-danger");
					
				});
				}
			else
				{
				Notifier.displayMsg("Updation failed, try again.","alert-danger");
				}
		},
			function(error){
			Notifier.displayMsg("Connection to the server is failed, try again later.","alert-danger");
			});
		
			
	};
	
	//function to manage forgot password link
	$scope.passwordReset=function()
	{
		if($scope.step2)
			{
			if($scope.answer == $rootScope.profile.answer)
				{
				$scope.step3=true;
				$scope.step2=false;
				}
			else
				Notifier.displayMsg("Wrong answer, try again.","alert-danger");
			
			}
		else if($scope.step3)
			{
			//save password in db
			//alert("updating password in db: "+$scope.newPass);
			var url="http://localhost:8080/rabsab/services/users/profile";
			//A JSON object is created.
			var usr={'id' :$rootScope.profile.profileId,
					'name':'',
					'mailId':'',
					'password' : $scope.newPass,
					'role': 1};
			$http.put(url,usr).then(function(response){
				if(response.data=="SUCCESS")
					{
					Notifier.displayMsg("Password is successfully reset, login now.","alert-success");
					$location.path('login');
					}
				else
					{
					Notifier.displayMsg("Password reset failed, try again.","alert-danger");
					
					}
			},function(error){
				Notifier.displayMsg("Connection to the server is failed, try again later.","alert-danger");
				
			});
			
			}
		else
			{
			//fetch question and answer from the db
			//alert("fetching profile using mailId:"+$scope.mailId);
			var url="http://localhost:8080/rabsab/services/users/profile/"+$scope.mailId;
			$http.get(url).then(function(response){
				var len=Object.keys(response.data).length;//length of data object is obtained
				//alert("response length: "+len);
				if(len>0)
					{
					$rootScope.profile=response.data;
					$scope.step2=true;
					}
				else
					{
					Notifier.displayMsg("Invalid Mailid, try again later.","alert-danger");
					
					}
			},function(error){
				Notifier.displayMsg("Connection to the server is failed, try again later.","alert-danger");
			});
			
			}
		
		
	};
	
	//function to load all the users
	$scope.loadUsers=function(){
		var url="http://localhost:8080/rabsab/services/users";
		//fetching users list
		$http.get(url).then(function(response){
			var len=Object.keys(response.data).length;//length of data object is obtained
			//alert("received data: "+JSON.stringify(response.data));
			if(len>0)
				{
				if(angular.isArray(response.data.list))
				$rootScope.userList=response.data.list;
				else
				{
					var ul=[];
					ul[0]=response.data.list;
					$rootScope.userList=ul;
					//alert(JSON.stringify(ul))
				}	
				//user data is set in scope.
				}
			else
				{
				Notifier.displayMsg("No user found.","alert-danger");
				
				}
		},function(error){
			Notifier.displayMsg("connection to server is failed.","alert-danger");
			
		});
		
	};
	
	//function to delete a user
	$scope.removeUser=function(usr)
	{
		//alert(usr.name+" is to be removed.");
		var url="http://localhost:8080/rabsab/services/users/"+usr.id;
		//sending delete request 
		$http.delete(url).then(
				function(response){
					if(response.data=="SUCCESS")
						{
						Notifier.displayMsg("Successfully deleted.","alert-success");
						$location.path('home');
							}
						else
						Notifier.displayMsg("Deletion failed, try again.","alert-failure");
					
				},function(error){
					Notifier.displayMsg("Communication to the server is failed.","alert-success");
					
				});
		$rootScope.userList=null;//list is removed from the scope.
	};
	
});


//book controller is defined & registered with the module
m1.controller('BookController',
		function($scope,$location,$rootScope,$http,Notifier){
	
	
	$scope.book_status=[1,2];//1-Available,2-Rented
	$scope.cats=['Best Sellers',
	                   'Fiction',
	                   'Biography',
	                   'Non Fiction',
	                   'Business',
	                   'Self Help',
	                   'Religious',
	                   'Course',
	                   'Competition',
	                   'Others'];
	
	$scope.category=$scope.cats[0];//default category
	
	$scope.getFile=function(files){
		//alert("file in ctrl: "+JSON.stringify(files));
		$scope.file=files[0];
	};
	
	
	$scope.postBook=function(){
		 var da = new FormData();
         da.append("title", $scope.title);
         da.append("category", $scope.category);
         da.append("rent", $scope.rent);
         da.append("book_img", $scope.file);
         da.append("userId",$rootScope.user.id);
		//alert("To be uploaded is: "+$scope.files[0]);
		var req = {
                method: 'POST',
                url: '/rabsab/services/books',
                data: da,
                headers: { 'Content-Type': undefined },
                  };
            
		$http(req).then(function (response) {
            	Notifier.displayMsg("Book posted successfully.","alert-success");
				$location.path('home');
            },function (err) { 
            	Notifier.displayMsg("Book posting failed, try again.","alert-failure");
				
            });
	};
	
	//function to load books of the current users
	$scope.loadUserBooks=function(){
		//alert("loading books of "+$rootScope.user.name);
		var url="/rabsab/services/books/"+$rootScope.user.id;
		//fetching books list
		$http.get(url).then(function(response){
			var len=Object.keys(response.data).length;//length of data object is obtained
			//alert("received data: "+JSON.stringify(response.data));
			if(len>0)
				{
				if(angular.isArray(response.data.list))
				$rootScope.bookList=response.data.list;
				else
				{
					var ul=[];
					ul[0]=response.data.list;
					$rootScope.bookList=ul;
					//alert(JSON.stringify(ul))
				}	
				}
			else
				{
				Notifier.displayMsg("No book found.","alert-danger");
				
				}
		},function(error){
			Notifier.displayMsg("connection to server is failed.","alert-danger");
			
		});
	}	
	
	//function to display details of a book
	$scope.showDetails=function(book){
		$rootScope.book=book;
		//loading owner of the book
		var url="/rabsab/services/books/owner/"+book.bookId;
		$http.get(url).then(function(response){
			var len=Object.keys(response.data).length;//length of data object is obtained
			//alert("owner details: "+JSON.stringify(response.data));
			if(len>0)
				{
				$rootScope.owner=response.data;
				}
			else
				{
				Notifier.displayMsg("Owner details coudn't be fetched right now.","alert-danger");
				
				}
		},function(error){
			Notifier.displayMsg("Connection to the server is failed, try again later.","alert-danger");
		});
		
		//changing the route to display the book
		$location.path('book_details');
	};
	
	//function to show edit book form
	$scope.editBook=function(bookId){
		
		$scope.updateId=bookId;
	};
	
	//function to update details of a book
	$scope.updateBook=function(bk){
		
		alert(JSON.stringify(bk)+" is the received object");
		 var book_new = {"bookId" : bk.bookId,
				 		 "title" : bk.title,
				 		"category" : bk.category,
				 		"rent" : bk.rent,
				 		"imageUrl" : bk.imageUrl,
				 		"userId" : bk.userId,
				 		"status" : bk.status};
		
		alert(JSON.stringify(book_new)+" is the object to be sent.");
		var url="/rabsab/services/books";
		//sending put request 
		$http.put(url,book_new).then(
				function(response){
					if(response.data=="SUCCESS")
						{
						Notifier.displayMsg("Successfully updated.","alert-success");
						}
						else
						Notifier.displayMsg("Updation failed, try again.","alert-failure");
					
				},function(error){
					Notifier.displayMsg("Communication to the server is failed.","alert-success");
					
				});
		$scope.updateId=0;
	};
	
	//function to update image
	$scope.updateImage=function(book){
		
		var da = new FormData();
        da.append("bookId", book.bookId);
        da.append("imgUrl", book.imageUrl);
        da.append("book_img", $scope.file);
        da.append("userId",book.userId);
		//alert("Image is to be changed for : "+JSON.stringify(da));
		var req = {
               method: 'POST',
               url: '/rabsab/services/books/changeImage',
               data: da,
               headers: { 'Content-Type': undefined },
                 };
           
		$http(req).then(function (response) {
           	Notifier.displayMsg("Image changed successfully.","alert-success");
				$location.path('home');
           },function (err) { 
           	Notifier.displayMsg("Image change failed, try again.","alert-failure");
				
           });
	
		
	};	
	
	
	//function to cancel update
	$scope.cancelUpdate=function(bookId){
		
		$scope.updateId=0;
	};
	//function to remove a book
	$scope.removeBook=function(bookId,imgUrl){
		
		//alert(usr.name+" is to be removed.");
		var url="/rabsab/services/books/"+bookId+"?imgUrl="+imgUrl;
		//sending delete request 
		$http.delete(url).then(
				function(response){
					if(response.data=="SUCCESS")
						{
						Notifier.displayMsg("Successfully deleted.","alert-success");
						}
						else
						Notifier.displayMsg("Deletion failed, try again.","alert-failure");
					
				},function(error){
					Notifier.displayMsg("Communication to the server is failed.","alert-success");
					
				});
		
		$location.path('books');
	};
	
	//function to load books by city
	$scope.bookInCity=function(){
		$rootScope.city=$scope.city;//to make it available in cityBooks.html
		alert("Book of the city "+$scope.city+" are to be fetched.");
		//alert("loading books of "+$rootScope.user.name);
		var url="/rabsab/services/books/byCity/"+$scope.city;
		//fetching books list
		$http.get(url).then(function(response){
			var len=Object.keys(response.data).length;//length of data object is obtained
			alert("received data: "+JSON.stringify(response.data));
			if(len>0)
				{
				if(angular.isArray(response.data.list))
				$rootScope.bookList=response.data.list;
				else
				{
					var ul=[];
					ul[0]=response.data.list;
					$rootScope.bookList=ul;
					//alert(JSON.stringify(ul))
				}	
				
				$location.path('books_by_city');
				}
			else
				{
				Notifier.displayMsg("No book found.","alert-danger");
				
				}
		},function(error){
			Notifier.displayMsg("connection to server is failed.","alert-danger");
			
		});
	
	};
	
	//function to load rented books
	$scope.loadRented=function(){
		$rootScope.status="Rented";
			var url="/rabsab/services/books/rented";
		//fetching books list
		$http.get(url).then(function(response){
			var len=Object.keys(response.data).length;//length of data object is obtained
			//alert("received data: "+JSON.stringify(response.data));
			if(len>0)
				{
				if(angular.isArray(response.data.list))
				$rootScope.bookList=response.data.list;
				else
				{
					var ul=[];
					ul[0]=response.data.list;
					$rootScope.bookList=ul;
					//alert(JSON.stringify(ul))
				}	
				
				$location.path('books_by_status');
				}
			else
				{
				Notifier.displayMsg("No book found.","alert-danger");
				
				}
		},function(error){
			Notifier.displayMsg("connection to server is failed.","alert-danger");
			
		});
	
	};
	
	//function to load available books
	$scope.loadAvailable=function(){
		$rootScope.status="Available";
			var url="/rabsab/services/books/available";
		//fetching books list
		$http.get(url).then(function(response){
			var len=Object.keys(response.data).length;//length of data object is obtained
			//alert("received data: "+JSON.stringify(response.data));
			if(len>0)
				{
				if(angular.isArray(response.data.list))
				$rootScope.bookList=response.data.list;
				else
				{
					var ul=[];
					ul[0]=response.data.list;
					$rootScope.bookList=ul;
					//alert(JSON.stringify(ul))
				}	
				
				$location.path('books_by_status');
				}
			else
				{
				Notifier.displayMsg("No book found.","alert-danger");
				
				}
		},function(error){
			Notifier.displayMsg("connection to server is failed.","alert-danger");
			
		});
	
	};
	
});
	

	//Home controller is defined & registered with the module
	m1.controller('HomeController',
			function($scope,$location,$rootScope,$http,Notifier){

	$scope.bmap=[];
	//function to load all the books category wise
	$scope.loadBooks=function(){
		//alert("loading books...");
		var url="/rabsab/services/books";
		//fetching books list
		$http.get(url).then(function(response){
			var len=Object.keys(response.data).length;//length of data object is obtained
			//alert("received data: "+JSON.stringify(response.data));
			if(len>0)
				{
				if(angular.isArray(response.data.booksList))
				response.data.booksList.forEach(function(obj){
					if(angular.isArray(obj.list))
						$scope.bmap.push(obj);
					else
						{
						var myobj={};
						myobj.category=obj.category;
						var list=[];
						list[0]=obj.list;
						myobj.list=list;
						$scope.bmap.push(myobj);
						}
						
				});
				
				else
				{
					var myobj={};
					myobj.category=response.data.booksList.category;
					myobj.list=response.data.booksList.list;
					$scope.bmap.push(myobj);
				}	
				//book data is set in scope.
				}
			else
				{
				Notifier.displayMsg("No book found.","alert-danger");
				
				}
		},function(error){
			Notifier.displayMsg("connection to server is failed.","alert-danger");
			
		});
		
	};
	
	//alert("before loadBooks() in controller...");
		$scope.loadBooks();
		//alert("after loadBooks in controller...");

});


