//defining custom directive to capture selected file details
m1.directive('fileSelected', function ($parse) {

    //directive object
    return {
    	 
         link: function (scope, element, attrs) {
        	 var onChange = $parse(attrs.fileSelected);
             element.on('change', function (event) {
            	 //alert("File in directive: "+JSON.stringify($("#upload").prop('files')[0]));
                 onChange(scope, { $files: event.target.files});
             });
         }
    }
} );